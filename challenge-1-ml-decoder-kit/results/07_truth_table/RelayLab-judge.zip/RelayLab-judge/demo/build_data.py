"""Build the static replay from a Git checkout at the recorded revision."""
import io
import json
from pathlib import Path
import subprocess
import sys

import numpy as np

REV = "36d51f6"
PREFIX = "challenge-1-ml-decoder-kit/results/"


def read(name):
    raw = subprocess.check_output(["git", "-C", sys.argv[1], "show", f"{REV}:{PREFIX}{name}"])
    return np.load(io.BytesIO(raw), allow_pickle=False)


pilot = read("relay_router_scaleup_p005.npz")
train = pilot["train_features"]
assert list(pilot["feature_names"]) == ["syndrome_weight", "iterations", "nonconverged",
                                        "posterior_abs_mean", "posterior_abs_p10"]
cut = [float(np.quantile(train[..., col], q)) for col, q in
       [(0, .75), (1, .5), (1, .90), (3, .25), (4, .25)]]


def keys(f):
    bits = [f[..., 2] > 0, f[..., 0] > cut[0], f[..., 1] > cut[1],
            f[..., 1] > cut[2], f[..., 3] < cut[3], f[..., 4] < cut[4]]
    return sum(bit.astype(int) << (5-i) for i, bit in enumerate(bits))


train_keys = keys(train)
cost_keys = keys(pilot["features"])
fail = pilot["train_fail"]
rescue = fail[..., 0] & ~fail[..., 1]
regress = ~fail[..., 0] & fail[..., 1]
strong_ms = 1000 * pilot["seconds"][..., 1]
cells = []
for k in range(64):
    sel = train_keys == k
    times = strong_ms[cost_keys == k]
    n = int(sel.sum())
    cells.append(dict(n=n, rescue=(rescue[sel].sum()+20*rescue.mean())/(n+20),
                      regress=(regress[sel].sum()+20*regress.mean())/(n+20),
                      cost=(times.sum()+20*strong_ms.mean())/(times.size+20)))


def stage(stage_id):
    return read(f"relay{stage_id}_p0.005_l0.0_unaware_s10_n10000_shard0of1.npz")


fast, strong = stage(1), stage(5)
for name in ["host", "seed", "p", "p_loss", "basis", "shot_idx", "workers", "stim_version"]:
    assert np.array_equal(fast[name], strong[name]), name
assert np.array_equal(fast["shot_idx"], np.arange(10000))
names = list(fast["feature_names"])
feat = fast["features"]
values = np.stack([feat[..., names.index("syndrome_weight")], fast["iterations"],
                   1-feat[..., names.index("converged")], feat[..., names.index("posterior_abs_mean")],
                   feat[..., names.index("posterior_abs_p10")]], axis=-1)
data = dict(cut=cut, cells=cells, costMean=float(strong_ms.mean()), keys=keys(values).ravel().tolist(),
            iterations=fast["iterations"].ravel().tolist(),
            flags=(fast["fail"].astype(int)+2*strong["fail"].astype(int)).ravel().tolist(),
            fast=np.round(fast["seconds"]*1000, 3).ravel().tolist(),
            strong=np.round(strong["seconds"]*1000, 3).ravel().tolist())
path = Path(__file__).with_name("data.js")
path.write_text("const DATA="+json.dumps(data, separators=(",", ":"), allow_nan=False)+";\n")
