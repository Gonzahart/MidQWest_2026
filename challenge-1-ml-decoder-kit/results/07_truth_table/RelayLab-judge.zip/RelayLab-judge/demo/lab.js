"use strict";
const $ = id => document.getElementById(id);
const D = DATA, total = D.keys.length, pairs = total / 2;
const fmt = n => n.toLocaleString("en-US", {maximumFractionDigits:1});
const bits = k => k.toString(2).padStart(6,"0");
const pct = n => (100*n).toFixed(1)+"%";
const avg = a => a.reduce((x,y)=>x+y,0)/a.length;
function quantile(sorted,q){
  const i=(sorted.length-1)*q, lo=Math.floor(i);
  return sorted[lo]+(i-lo)*(sorted[Math.ceil(i)]-sorted[lo]);
}
const fastPairs=Array.from({length:pairs},(_,i)=>D.fast[2*i]+D.fast[2*i+1]).sort((a,b)=>a-b);
const simpleOrder=Array.from({length:total},(_,i)=>i).sort((a,b)=>
  (D.keys[b]>>5)-(D.keys[a]>>5)||D.iterations[b]-D.iterations[a]||a-b);
let route=[], table=[], elapsed=[], price=0, profile=null;
const costLabel=document.createElement("label"),costSource=document.createElement("select");
costLabel.textContent="Decision cost profile";costLabel.htmlFor="costSource";costSource.id="costSource";
costSource.add(new Option("Archived CPU calibration","cache"));
costSource.add(new Option("Local CPU calibration","local"));costSource.options[1].disabled=true;
$("price").nextElementSibling.after(costLabel,costSource);costSource.onchange=replay;
function cost(c){
  const local=profile?.rows.find(r=>r.device==="CPU"&&r.stop===5);
  return c.cost*(costSource.value==="local"&&local?local.mean_ms/(2*D.costMean):1);
}
const reliability=document.createElement("article");
reliability.innerHTML='<h2>Benefit calibration</h2><p>Predicted and observed net rescues per 100 basis shots, grouped by the predicted benefit.</p><div class="scroll"><table><thead><tr><th>Prediction band</th><th>Shots</th><th>Predicted</th><th>Observed</th></tr></thead><tbody id="reliability"></tbody></table></div>';
$("rules").append(reliability);
function replay(){
  price=Number($("price").value)/1000;
  $("priceValue").value=price.toFixed(3)+" / s";
  table=D.cells.map(c=>c.n>=12 && c.rescue-c.regress>price*cost(c)/1000);
  const selected=$("policy").value;
  route=D.keys.map(k=>table[k]);
  const budget=route.filter(Boolean).length;
  if(selected==="simple"){route.fill(false);for(const i of simpleOrder.slice(0,budget))route[i]=true}
  if(selected==="strong"||selected==="fast")route.fill(selected==="strong");
  let failures=0; elapsed=[];
  for(let p=0;p<pairs;p++){
    let ms=0, failed=false;
    for(const i of [2*p,2*p+1]){
      const flag=D.flags[i];
      failed=failed||Boolean(flag & (route[i]?2:1));
      ms+=(selected==="strong"?0:D.fast[i])+(route[i]?D.strong[i]:0);
    }
    elapsed.push(ms);failures+=Number(failed);
  }
  elapsed.sort((a,b)=>a-b);
  $("failed").textContent=fmt(failures);
  $("mean").textContent=fmt(avg(elapsed))+" ms";
  $("tail").textContent=fmt(quantile(elapsed,.99))+" ms";
  $("routed").textContent=selected==="strong"?"100% direct":pct(route.filter(Boolean).length/total);
  $("next").disabled=!route.includes(true);
  draw();inspect();renderRules();
}
function draw(){
  const el=$("chart"),w=el.clientWidth,h=el.clientHeight;
  if(!w)return;
  const dpr=window.devicePixelRatio||1;el.width=w*dpr;el.height=h*dpr;
  const ctx=el.getContext("2d");ctx.scale(dpr,dpr);
  const l=52,r=w-15,t=18,b=h-28;
  const ceiling=Math.max(100,...[elapsed,fastPairs].map(a=>quantile(a,.99)));
  const max=Math.ceil(ceiling/1000)*1000;
  const y=v=>b-(b-t)*v/max;
  ctx.font="11px monospace";ctx.fillStyle="#c3d9d0";
  for(let j=0;j<=3;j++){
    const v=j*max/3;ctx.strokeStyle="#3b5657";ctx.beginPath();ctx.moveTo(l,y(v));ctx.lineTo(r,y(v));ctx.stroke();
    ctx.fillText(v>=1000?(v/1000).toFixed(1)+"k":String(Math.round(v)),2,y(v)+4);
  }
  for(const q of [0,25,50,75,99])ctx.fillText("P"+q,Math.min(r-21,l+(r-l)*q/99-4),h-6);
  for(const [a,color] of [[fastPairs,"#efad6e"],[elapsed,"#a7eeaa"]]){
    ctx.strokeStyle=color;ctx.lineWidth=2.5;ctx.beginPath();
    for(let j=0;j<=198;j++){const x=l+(r-l)*j/198,v=y(quantile(a,j/200));j?ctx.lineTo(x,v):ctx.moveTo(x,v)}
    ctx.stroke();
  }
}
function inspect(){
  const p=Math.max(1,Math.min(pairs,Math.trunc(Number($("shot").value))||1));
  const i=2*(p-1)+Number($("basis").value==="Z"), k=D.keys[i], c=D.cells[k],f=D.flags[i];
  const decision=route[i]?($("policy").value==="strong"?"Strong only":"Escalate"):"Accept fast";
  const entries=[["Diagnostic bits",bits(k)],["Net benefit",((c.rescue-c.regress)*100).toFixed(2)+" pp"],
                 ["Estimated extra time",fmt(cost(c))+" ms"],["Decision",decision]];
  $("detail").innerHTML=entries.map(([l,v])=>"<div><label>"+l+"</label><b>"+v+"</b></div>").join("")+
    "<p>Training support: "+c.n+" basis shots. Recorded outcome on this shot: fast "+(f&1?"failed":"correct")+", strong "+(f&2?"failed":"correct")+".</p>";
}
// Enumerate implicants on six bits, retain primes, then greedily cover the ON set.
function cover(on){
  const terms=[];
  for(let mask=0;mask<64;mask++)for(let val=0;val<64;val++){
    if((val&mask)!==val)continue;
    const keys=on.map((_,k)=>k).filter(k=>(k&mask)===val);
    if(keys.every(k=>on[k]))terms.push({mask,val,keys});
  }
  const primes=terms.filter(a=>!terms.some(b=>b.keys.length>a.keys.length&&(a.mask&b.mask)===b.mask&&(a.val&b.mask)===b.val));
  const left=new Set(on.flatMap((v,k)=>v?[k]:[])),out=[];
  while(left.size){
    const gain=t=>t.keys.filter(k=>left.has(k)).length;
    primes.sort((a,b)=>gain(b)-gain(a)||b.keys.length-a.keys.length);
    const t=primes.shift();out.push(t);t.keys.forEach(k=>left.delete(k));
  }
  if(on.some((v,k)=>v!==out.some(t=>(k&t.mask)===t.val)))throw Error("Rule verification failed");
  return out;
}
function renderRules(){
  const terms=cover(table);
  $("cubes").innerHTML=terms.length?terms.map(t=>'<span class="chip">'+bits(t.mask).split("").map((v,i)=>v==="0"?"–":bits(t.val)[i]).join("")+"</span>").join(""):"Always accept the fast result.";
  $("bitNames").textContent="Bits left to right: nonconverged · syndrome weight > "+fmt(D.cut[0])+" · iterations > "+fmt(D.cut[1])+" · iterations > "+fmt(D.cut[2])+" · mean confidence < "+fmt(D.cut[3])+" · lower-tail confidence < "+fmt(D.cut[4])+". A dash matches either bit. Greedy prime-implicant cover verified on all 64 rows.";
  $("cells").innerHTML=D.cells.map((c,k)=>"<tr>"+[bits(k),c.n,pct(c.rescue),pct(c.regress),fmt(cost(c))+" ms",table[k]?"Escalate":"Accept fast"].map(v=>"<td>"+v+"</td>").join("")+"</tr>").join("");
}
document.querySelectorAll("[data-view]").forEach(button=>button.onclick=()=>{
  for(const name of ["replay","rules","machine"])$(name).hidden=name!==button.dataset.view;
  document.querySelectorAll("[data-view]").forEach(b=>b.removeAttribute("aria-current"));
  button.setAttribute("aria-current","page");draw();
});
$("price").oninput=replay;$("policy").onchange=replay;
$("basis").onchange=inspect;$("shot").onchange=()=>{$("shot").value=Math.min(pairs,Math.max(1,Math.trunc(Number($("shot").value))||1));inspect()};
$("next").onclick=()=>{
  const idx=(Number($("shot").value)-1)*2+Number($("basis").value==="Z");
  for(let n=1;n<=total;n++){const i=(idx+n)%total;if(route[i]){$("shot").value=1+(i>>1);$("basis").value=i%2?"Z":"X";inspect();break}}
};
function showProfile(p){
  profile=p;$("profile").textContent=p.rows.map(r=>r.device+" relay-BP-"+r.stop+": "+fmt(r.mean_ms)+" ms mean per X+Z pair").join("  ·  ");
  $("export").hidden=false;
  costSource.options[1].disabled=!p.rows.some(r=>r.device==="CPU"&&r.stop===5);
  if(p.warnings?.length)$("profile").textContent+=" · "+p.warnings.join(" · ");
  replay();
}
async function hardware(){
  $("tune").disabled=true;
  if(location.protocol==="file:"){$("device").textContent="Launch Relay Lab with the included Windows launcher to benchmark the local WSL decoder.";return}
  try{
    const res=await fetch("/api/device");if(!res.ok)throw Error();
    const d=await res.json();$("device").textContent=[d.cpu,d.gpu,d.ram].join(" · ");
    $("tune").disabled=false;
    if(d.profile)showProfile(d.profile);
  }catch{$("device").textContent="The calibration service is unavailable. Replay is available offline."}
}
$("tune").onclick=async()=>{
  $("tune").disabled=true;$("status").textContent="Warming decoders and timing 8 paired shots at p = 0.005. This may take a minute.";
  try{
    const r=await fetch("/api/tune",{method:"POST",headers:{"X-Relay-Lab":"calibrate"}});
    const p=await r.json();if(!r.ok)throw Error(p.error||"Calibration failed");
    showProfile(p);$("status").textContent="Local profile saved. Short-pack means characterize this machine. Replay still uses its archived CPU costs.";
  }catch(e){$("status").textContent=e.message}finally{$("tune").disabled=false}
};
$("export").onclick=()=>{
  const url=URL.createObjectURL(new Blob([JSON.stringify(profile,null,2)],{type:"application/json"}));
  const a=document.createElement("a");a.href=url;a.download="relay-lab-profile.json";a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);
};
const bins=[[-Infinity,0],[0,.01],[.01,.05],[.05,.15],[.15,Infinity]];
$("reliability").innerHTML=bins.map(([lo,hi],b)=>{
  let n=0,expect=0,actual=0;
  D.keys.forEach((k,i)=>{const c=D.cells[k],v=c.rescue-c.regress;if(v>=lo&&v<hi){n++;expect+=v;actual+=(D.flags[i]&1)-(D.flags[i]>>1)}});
  return "<tr>"+[["Below 0","0 to <1","1 to <5","5 to <15","15 and above"][b],fmt(n),n?(100*expect/n).toFixed(2):"—",n?(100*actual/n).toFixed(2):"—"].map(v=>"<td>"+v+"</td>").join("")+"</tr>";
}).join("");
window.addEventListener("resize",draw);replay();hardware();
