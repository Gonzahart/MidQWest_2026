# Judge quick start · Infleqtion Challenge 1

**What was learned?** A six-bit policy uses diagnostics from a fast Gross-code decoder to decide whether the stronger decoder is worth its extra cost. Training labels distinguish a rescue (+1), a regression (−1), and equal correctness (0). Measured strong-pass time and the fixed price determine the action for each of the 64 possible diagnostic patterns. The stronger decoder and the GPU implementation are distinct from the learned routing policy.

## 1. See the experiment without installing software

Open **comparison.png** for the zero-loss sweep, or **reference.csv** for logical error per cycle, failed pairs, mean and p99. Each of the 12 rows uses 1,000 pairs at the specified noise rate. Open **demo/index.html** for the separate 10,000-pair interactive seed-10 replay. Choose **Next escalation**, inspect the six bits, then open **Truth table**. The interactive demo and the three-rate scorecard use different test packs.

## 2. Reproduce the scorecard offline

From this extracted folder with Python 3.11+ and NumPy installed:

```bash
python judge.py
```

Expected final line: **PASS: all 12 replay rows match the supplied reference.** Use `python -m pip install numpy` if needed. The test checks aligned shot indices and run metadata across BP-OSD, relay-BP-1 and relay-BP-5. For each basis shot it calculates the six learned input bits from the fast diagnostics, applies the frozen table, selects the recorded outcome and charges both calls for escalations. The truth labels enter scoring only. It compares the recomputed metrics with the reference. CPU and NumPy suffice; this command uses no network or GPU.

## 3. Challenge it with your own seed

Use a Linux or WSL environment with the team's kit requirements and relay-bp installed. The [kit README](https://github.com/Gonzahart/MidQWest_2026/tree/main/challenge-1-ml-decoder-kit) gives the baseline setup. From this folder, use that environment's Python, replacing the kit path as needed:

```bash
KIT="$HOME/MidQWest_2026/challenge-1-ml-decoder-kit"
"$KIT/.venv/bin/python" judge.py --kit "$KIT" --shots 8 --seed 801 --csv smoke.csv
```

This runs the actual decoders and six-bit routing policy at all three rates. It samples one array per basis and gives each method the same inputs, excludes a warm-up and times each decode to a host correction. It reports logical error per cycle, latency and Linux whole-process peak resident memory. One worker runs the methods sequentially. Increase `--shots` to 1,000 or more for a longer evaluation; eight pairs are a wiring check. Expect different counts from a new sample. Live routed results can also differ from replay on the same syndromes because the stateful fallback decoder is invoked only on escalations.

## Scope and evidence

- The zero-loss scorecard uses the [single-worker seed-16 files](https://github.com/Gonzahart/MidQWest_2026/tree/db2b907/challenge-1-ml-decoder-kit/results/timing/final%20timing), matched within each p, with X seed 16 and Z seed 17. Replay excludes actual routing overhead. Pair failure is either basis failing; logical rate per cycle is one minus the twelfth root of the pair success rate.
- The six-bit router was trained on zero-loss p=0.005 data using seeds 41/42, with strong-pass cost estimates from 2/3. The same frozen table and price of 0.035 expected failures avoided per second are used for all three evaluation rates. The model is in **inputs/policy.json**. The complete training/data-build script **demo/build_data.py** can regenerate **demo/data.js** from the team Git clone containing revision `36d51f6`; the policy JSON contains its cut points and cells plus the frozen price.
- For generating the policy's original training and cost caches, see the [team's scale-up command](https://github.com/Gonzahart/MidQWest_2026/blob/36d51f6/challenge-1-ml-decoder-kit/results/README.md) for `relay_router_scaleup_p005.npz`. The live judge script itself generates fresh evaluation data from the kit circuits.
- At p=0.005 the router had 71 failed pairs versus 76 for fast-only and 77 for strong-only in these 1,000 pairs. It had lower mean time than strong-only and a higher p99. At the lower noise rates its failed-pair counts tied fast-only. These are descriptive results.
- **Heralded loss** is a separate team experiment. See the [matched loss controls and flag robustness results](https://github.com/Gonzahart/MidQWest_2026/blob/ff1a70d/challenge-1-ml-decoder-kit/results/README.md) and [loss-aware evaluation code](https://github.com/Gonzahart/MidQWest_2026/blob/main/challenge-1-ml-decoder-kit/evaluate.py). **GPU acceleration** is also a separate [published hardware experiment](https://github.com/Gonzahart/MidQWest_2026/tree/main/challenge-1-ml-decoder-kit/results/Sean%20GPU-relay).
- For submission, publish this folder beside the existing team evaluation scripts and link this page from the repository's front README. Include the short team presentation or demo. The organizer's [written brief](https://github.com/Gonzahart/MidQWest_2026/blob/main/docs/reference/INFLEQTION_CHALLENGE_README.md) defines the deliverables.
