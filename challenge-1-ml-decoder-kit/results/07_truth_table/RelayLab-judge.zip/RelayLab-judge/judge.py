"""python judge.py for offline replay; see START-HERE.md for live decoding."""
import argparse
import csv
import json
import os
from pathlib import Path
import sys
from time import perf_counter

for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "RAYON_NUM_THREADS"):
    os.environ[key] = "1"
import numpy as np

ROOT = Path(__file__).resolve().parent
POLICY = json.loads((ROOT / "inputs/policy.json").read_text())
TABLE = np.array([c["n"] >= 12 and c["rescue"] - c["regress"] > POLICY["price"] * c["cost"] / 1000
                  for c in POLICY["cells"]])
RATES = (.003, .004, .005)


def route(converged, weight, iterations, mean, lower):
    a, b, c, d, e = POLICY["cut"]
    key = (converged == 0)*32 + (weight > a)*16 + (iterations > b)*8 + (iterations > c)*4
    return TABLE[key + (mean < d)*2 + (lower < e)]


def replay(p):
    def load(name):
        path = ROOT / "inputs" / f"{name}_p{p}_l0.0_unaware_s16_n1000_shard0of1.npz"
        with np.load(path, allow_pickle=False) as z:
            return {k: z[k] for k in z.files}
    fast, strong, osd = (load(name) for name in ("relay1","relay5","bposd"))
    for data in (strong, osd):
        for k in ("shot_idx","host","seed","p","p_loss","basis","cycles","workers","stim_version","shots"):
            np.testing.assert_array_equal(fast[k], data[k], err_msg=k)
    def col(key):
        return fast["features"][..., list(fast["feature_names"]).index(key)]
    selected = route(col("converged"), col("syndrome_weight"), fast["iterations"],
                     col("posterior_abs_mean"), col("posterior_abs_p10"))
    for name,data in (("BP-OSD",osd),("Relay-1",fast),("Relay-5",strong)):
        yield name,data["fail"],data["seconds"],None
    yield ("Six-bit router", np.where(selected,strong["fail"],fast["fail"]),
           fast["seconds"] + selected*strong["seconds"], int(selected.sum()))


class SixBitDecoder:
    def __init__(self,H,priors):
        from decoders import relay_decoder
        self.fast = relay_decoder(H,priors,stop_nconv=1)
        self.strong = relay_decoder(H,priors,stop_nconv=5)
        self.calls = 0

    def decode(self, syndrome):
        r = self.fast.decode_detailed(syndrome)
        conf = np.nan_to_num(np.abs(np.asarray(r.posterior_ratios)),nan=0).clip(0,100)
        if route(r.success,syndrome.sum(),r.iterations,conf.mean(),np.percentile(conf,10)):
            self.calls += 1
            return self.strong.decode(syndrome)
        return r.decoding


def live(p,shots,seed):
    from circuit import sample
    from decoders import bposd_decoder,relay_decoder
    from loss_circuit import lossy_circuit,lossy_dem_matrices
    names = ("BP-OSD","Relay-1","Relay-5","Six-bit router")
    fail = {n:np.zeros((shots,2),bool) for n in names}
    seconds = {n:np.zeros((shots,2)) for n in names}
    escalated = 0
    for b,basis in enumerate("XZ"):
        circuit = lossy_circuit(basis,p,0)
        H,L,priors,ids = lossy_dem_matrices(circuit,basis,False)
        det,obs = sample(circuit,shots+1,seed+b)
        decoders = [bposd_decoder(H,priors),relay_decoder(H,priors,stop_nconv=1),
                    relay_decoder(H,priors,stop_nconv=5),SixBitDecoder(H,priors)]
        for name,decoder in zip(names,decoders):
            decoder.decode(det[0,ids])
            if name == names[-1]: decoder.calls=0
            for j in range(shots):
                s=det[j+1,ids]
                start=perf_counter()
                error=np.asarray(decoder.decode(s),np.uint8)
                seconds[name][j,b]=perf_counter()-start
                fail[name][j,b]=np.any((L@error)%2 != obs[j+1])
            if name==names[-1]: escalated+=decoder.calls
    for n in names:
        yield n,fail[n],seconds[n],escalated if n==names[-1] else None


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kit",type=Path,help="Run real decoders using this installed kit directory")
    parser.add_argument("--shots",type=int,default=8,help="Scored pairs per rate in live mode")
    parser.add_argument("--seed",type=int,default=801,help="Live X seed; Z uses the next seed")
    parser.add_argument("--csv",type=Path)
    args=parser.parse_args()
    if args.shots<1 or args.seed<0: parser.error("Choose positive shots and a nonnegative seed")
    target=args.csv.resolve() if args.csv else None
    if args.kit:
        kit=args.kit.resolve()
        sys.path.insert(0,str(kit))
        os.chdir(kit)
    rows=[]
    for p in RATES:
        for name,f,t,n in (live(p,args.shots,args.seed) if args.kit else replay(p)):
            failed=f.any(axis=1)
            ms=t.sum(axis=1)*1000
            row=dict(mode="live" if args.kit else "replay",p=p,decoder=name,pairs=len(f),
                     failed_pairs=int(failed.sum()),ler_per_cycle=1-(1-failed.mean())**(1/12),
                     mean_ms=float(ms.mean()),p99_ms=float(np.percentile(ms,99)),escalations=n)
            rows.append(row)
            print(f"{p:.3f}  {name:14}  {row['failed_pairs']:4}/{len(f)} failed  "
                  f"LER/cycle {row['ler_per_cycle']:.6f}  mean {ms.mean():8.1f} ms  "
                  f"p99 {row['p99_ms']:8.1f} ms",flush=True)
    if not args.kit:
        with (ROOT/"reference.csv").open() as stream:
            reference=list(csv.DictReader(stream))
        assert len(rows)==len(reference)==12
        for row,expected in zip(rows,reference,strict=True):
            for k in ("decoder","mode","pairs","failed_pairs","escalations"):
                assert str(row[k] if row[k] is not None else "")==expected[k], k
            for k in ("p","ler_per_cycle","mean_ms","p99_ms"):
                np.testing.assert_allclose(row[k],float(expected[k]),rtol=1e-10,atol=1e-12)
        print("PASS: all 12 replay rows match the supplied reference.")
    if target:
        with target.open("w",newline="") as stream:
            w=csv.DictWriter(stream,fieldnames=rows[0]); w.writeheader(); w.writerows(rows)
    if args.kit and sys.platform.startswith("linux"):
        import resource
        print(f"Whole evaluation process peak RSS: {resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024:.1f} MiB")

if __name__=="__main__": main()
